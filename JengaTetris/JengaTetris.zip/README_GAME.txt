HOW TO PLAY :

- controls 
	- arrow (down) to move the current piece down
	- S and D to rotate the piece 90 degrees
	- Esc to pause

CONFIGURATION SETTING: 

- On Session.cs have a const MAX_TO_WIN to define how many pieces are stacked to get win
and const MAX_TO_LOSE define how many pieces have to fall for you to get lose
         