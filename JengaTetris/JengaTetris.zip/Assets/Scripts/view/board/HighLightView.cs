﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assets.Scripts.view.common;

namespace Assets.Scripts.view.board
{
    public class HighLightView:GameComponent
    {

    }
}
