﻿using Assets.Scripts.view.common;
using UnityEngine;

namespace Assets.Scripts.view.board
{
    public class BoardBottom : GameComponent
    {

    }
}